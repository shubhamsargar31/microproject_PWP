function startScan(type) {
    alert("Starting " + type + " scan!");
}