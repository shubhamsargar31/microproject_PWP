from flask import Flask, render_template, request, jsonify
from scanners.web_scanner import scan_website

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.route("/scan", methods=["POST"])
def scan():
    data = request.json
    target = data["target"]
    result = scan_website(target)
    return jsonify({"result": result})

if __name__ == "__main__":
    app.run(debug=True)
