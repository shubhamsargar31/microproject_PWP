def scan_website(target):
    return f'Scanning website: {target}'